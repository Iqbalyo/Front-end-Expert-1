Drawer = document.querySelector(".drawer");
Drawer.onclick = function() {
    nav = document.querySelector(".nav-bar");
    nav.classList.toggle("active")
}