Drawer = document.querySelector(".drawer");
Drawer.onclick = function() {
    nav = document.querySelector(".nav__links");
    nav.classList.toggle("active")
}